# Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/themustafaomar/pen/jLMPKm](https://codepen.io/themustafaomar/pen/jLMPKm).

Simple dashboard UI for inspiration.