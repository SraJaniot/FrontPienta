# CSS radio buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/AngelaVelasquez/pen/DGeErL](https://codepen.io/AngelaVelasquez/pen/DGeErL).

A CSS Trick to style a radio button .  

Resource:
http://css-tricks.com/almanac/selectors/c/checked/