# html forms

A Pen created on CodePen.io. Original URL: [https://codepen.io/gymratpacks/pen/VKzBEp](https://codepen.io/gymratpacks/pen/VKzBEp).

An HTML Form to use as a template