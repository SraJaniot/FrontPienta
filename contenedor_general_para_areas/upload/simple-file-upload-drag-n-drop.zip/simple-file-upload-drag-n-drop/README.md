# Simple File Upload Drag n' Drop

A Pen created on CodePen.io. Original URL: [https://codepen.io/mavieth/pen/evJjpo](https://codepen.io/mavieth/pen/evJjpo).

